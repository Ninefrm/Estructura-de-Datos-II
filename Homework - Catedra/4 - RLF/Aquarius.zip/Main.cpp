#include <iostream>
#include "Menu.h"


using namespace std;

int main()
{
    Menu m;
    m.MENU();
    return 0;
}
