#include "Login.h"

int main(int argc, char const *argv[]) {
  Login L;
  Profile GodMode;
  // GodMode.Add();
  // GodMode.Show();
  system("cls");
  L.Sesion();
  return 0;
}
